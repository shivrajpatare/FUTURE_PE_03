import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Dumbbell } from 'lucide-react';

function Navbar() {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path ? "text-blue-400" : "text-gray-300 hover:text-white";
  };

  return (
    <nav className="fixed w-full z-50 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <Dumbbell className="w-8 h-8 text-blue-400" />
            <span className="text-xl font-bold">AI Gym</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className={`${isActive('/')} font-medium transition-colors`}>
              Home
            </Link>
            <Link to="/products" className={`${isActive('/products')} font-medium transition-colors`}>
              Products
            </Link>
            <Link to="/about" className={`${isActive('/about')} font-medium transition-colors`}>
              About
            </Link>
            <Link to="/support" className={`${isActive('/support')} font-medium transition-colors`}>
              Support
            </Link>
            <Link to="/contact" className={`${isActive('/contact')} font-medium transition-colors`}>
              Contact
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Link 
              to="/products" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition-all"
            >
              Shop Now
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar