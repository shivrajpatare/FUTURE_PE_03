import React from 'react';
import { 
  Brain, 
  Cpu, 
  Wifi, 
  Smartphone,
  Check,
  ChevronRight
} from 'lucide-react';

function Products() {
  const products = [
    {
      name: "AI Power Rack",
      price: "4,999",
      image: "https://images.unsplash.com/photo-1638805981949-362f5964521e?auto=format&fit=crop&w=800",
      description: "Smart power rack with AI form tracking and real-time coaching",
      features: [
        "3D motion tracking",
        "Real-time form correction",
        "Auto-spotting system",
        "Voice-activated controls"
      ]
    },
    {
      name: "Smart Bench Pro",
      price: "2,999",
      image: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=800",
      description: "Intelligent bench with weight detection and form analysis",
      features: [
        "Weight sensing technology",
        "Form analysis",
        "Workout tracking",
        "Bluetooth connectivity"
      ]
    },
    {
      name: "AI Trainer Treadmill",
      price: "3,499",
      image: "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?auto=format&fit=crop&w=800",
      description: "Advanced treadmill with adaptive training programs",
      features: [
        "Adaptive speed control",
        "Gait analysis",
        "Virtual running routes",
        "Heart rate optimization"
      ]
    }
  ];

  const specs = [
    {
      icon: <Brain className="w-6 h-6" />,
      title: "AI Processing",
      description: "Advanced neural networks for real-time movement analysis"
    },
    {
      icon: <Cpu className="w-6 h-6" />,
      title: "Computing Power",
      description: "Dedicated processor for instant feedback and adjustments"
    },
    {
      icon: <Wifi className="w-6 h-6" />,
      title: "Connectivity",
      description: "WiFi and Bluetooth for seamless data sync"
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: "Mobile Integration",
      description: "iOS and Android apps for tracking and control"
    }
  ];

  return (
    <div className="pt-16">
      {/* Products Hero */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-center mb-8">
            Our Smart Fitness Equipment
          </h1>
          <p className="text-xl text-gray-400 text-center max-w-3xl mx-auto mb-16">
            Experience the perfect fusion of cutting-edge technology and premium fitness equipment.
            Each piece is designed to deliver personalized training and optimal results.
          </p>
          
          {/* Product Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <div key={index} className="bg-gray-800 rounded-xl overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2">{product.name}</h3>
                  <p className="text-gray-400 mb-4">{product.description}</p>
                  <div className="text-3xl font-bold mb-6">
                    ${product.price}
                  </div>
                  <ul className="space-y-2 mb-6">
                    {product.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-center gap-2 text-gray-300">
                        <Check className="w-5 h-5 text-blue-400" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all">
                    Learn More <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Specs */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">
            Technical Specifications
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {specs.map((spec, index) => (
              <div key={index} className="p-6 rounded-xl bg-gray-900 border border-gray-700">
                <div className="text-blue-400 mb-4">{spec.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{spec.title}</h3>
                <p className="text-gray-400">{spec.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Products;