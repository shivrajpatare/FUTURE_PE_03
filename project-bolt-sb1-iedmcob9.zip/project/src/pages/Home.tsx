import React, { useState } from 'react';
import { 
  Brain, 
  Timer, 
  Trophy,
  BarChart3,
  ChevronRight,
  Play,
  Check,
  Star
} from 'lucide-react';

function Home() {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);

  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI-Powered Coaching",
      description: "Real-time form correction and personalized workout adjustments powered by advanced machine learning"
    },
    {
      icon: <Timer className="w-8 h-8" />,
      title: "Adaptive Progression",
      description: "Smart weight and resistance adjustments based on your performance and recovery"
    },
    {
      icon: <Trophy className="w-8 h-8" />,
      title: "Goal Achievement",
      description: "Data-driven workout plans that evolve with your progress"
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: "Performance Analytics",
      description: "Comprehensive tracking and insights to optimize your fitness journey"
    }
  ];

  const plans = [
    {
      name: "Starter",
      price: "2,499",
      features: ["Basic AI coaching", "Form correction", "Progress tracking", "Mobile app access"]
    },
    {
      name: "Pro",
      price: "3,499",
      features: ["Advanced AI coaching", "Custom workout plans", "Recovery insights", "Priority support", "Premium content"]
    },
    {
      name: "Elite",
      price: "4,999",
      features: ["Full AI suite", "Personal training integration", "Multi-user profiles", "Lifetime warranty", "White glove setup"]
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <header className="relative min-h-screen flex items-center pt-16">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1920"
            alt="Background"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="container mx-auto px-4 py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-6xl font-bold mb-6 leading-tight">
              Transform Your Workouts with
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600"> AI-Powered</span> Equipment
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Experience the future of fitness with smart equipment that adapts to you. 
              Get real-time coaching, tracking, and personalized workouts powered by artificial intelligence.
            </p>
            <div className="flex gap-4">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold flex items-center gap-2 transition-all">
                Get Started <ChevronRight className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setIsVideoPlaying(true)}
                className="border border-white/30 hover:border-white/50 px-8 py-4 rounded-lg font-semibold flex items-center gap-2 transition-all"
              >
                Watch Demo <Play className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-8">
              <div className="border border-white/10 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-3xl font-bold text-blue-400">98%</div>
                <div className="text-sm text-gray-400">Form Improvement</div>
              </div>
              <div className="border border-white/10 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-3xl font-bold text-purple-400">2.5x</div>
                <div className="text-sm text-gray-400">Faster Results</div>
              </div>
              <div className="border border-white/10 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-3xl font-bold text-blue-400">50k+</div>
                <div className="text-sm text-gray-400">Active Users</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-32 bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">
            Revolutionary Features
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="p-6 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 hover:border-blue-500 transition-all">
                <div className="text-blue-400 mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-32 bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Real Results, Real Stories</h2>
              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                    <Star className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Sarah M.</h3>
                    <p className="text-gray-400">
                      "The AI coaching has completely transformed my workout routine. 
                      I've seen more progress in 3 months than in my previous year of training."
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
                    <Star className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">James K.</h3>
                    <p className="text-gray-400">
                      "As a personal trainer, I'm amazed by the accuracy of the form correction. 
                      It's like having an expert coach watching every rep."
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1549060279-7e168fcee0c2?auto=format&fit=crop&w=1024" 
                alt="Transformation" 
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-gray-900 p-6 rounded-xl border border-gray-700">
                <div className="text-3xl font-bold text-blue-400 mb-1">87%</div>
                <div className="text-sm text-gray-400">Average Strength Increase</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-32 bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Choose Your Plan</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div key={index} className="rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 p-8">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="text-4xl font-bold mb-6">
                  ${plan.price}
                  <span className="text-lg text-gray-400 font-normal">/unit</span>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-center gap-2">
                      <Check className="w-5 h-5 text-blue-400" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all">
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;