import React from 'react';
import { 
  HelpCircle, 
  Book, 
  Video, 
  MessageCircle,
  ChevronRight,
  Search
} from 'lucide-react';

function Support() {
  const faqs = [
    {
      question: "How does the AI coaching work?",
      answer: "Our AI system uses advanced computer vision to analyze your form in real-time, providing immediate feedback and adjustments to optimize your workout."
    },
    {
      question: "What happens if the equipment needs maintenance?",
      answer: "We offer 24/7 support and next-day service for all maintenance issues. Our equipment also performs self-diagnostics to prevent potential problems."
    },
    {
      question: "Can multiple people use the same equipment?",
      answer: "Yes! Our equipment supports multiple user profiles, each with their own personalized settings, progress tracking, and AI recommendations."
    },
    {
      question: "Is internet connection required?",
      answer: "While an internet connection enhances the experience with cloud features, our equipment maintains core functionality offline."
    }
  ];

  const resources = [
    {
      icon: <Book className="w-6 h-6" />,
      title: "User Guides",
      description: "Comprehensive documentation for all our equipment"
    },
    {
      icon: <Video className="w-6 h-6" />,
      title: "Video Tutorials",
      description: "Step-by-step visual guides for setup and usage"
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "Community Forum",
      description: "Connect with other users and share experiences"
    },
    {
      icon: <HelpCircle className="w-6 h-6" />,
      title: "FAQ",
      description: "Quick answers to common questions"
    }
  ];

  return (
    <div className="pt-16">
      {/* Support Hero */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              How Can We Help You?
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              Find answers, manage your account, and get help with your AI Gym equipment
            </p>
            <div className="relative">
              <input
                type="text"
                placeholder="Search for help..."
                className="w-full px-6 py-4 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </div>
        </div>
      </section>

      {/* Resources Section */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Support Resources</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {resources.map((resource, index) => (
              <div key={index} className="p-6 rounded-xl bg-gray-900 border border-gray-700 hover:border-blue-500 transition-all cursor-pointer">
                <div className="text-blue-400 mb-4">{resource.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
                <p className="text-gray-400 mb-4">{resource.description}</p>
                <div className="flex items-center text-blue-400">
                  Learn More <ChevronRight className="w-4 h-4 ml-1" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
              <div key={index} className="mb-6">
                <div className="flex items-start gap-4 p-6 rounded-xl bg-gray-800 border border-gray-700">
                  <div className="flex-shrink-0">
                    <HelpCircle className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
                    <p className="text-gray-400">{faq.answer}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Still Need Help?</h2>
          <p className="text-xl text-gray-400 mb-8">
            Our support team is available 24/7 to assist you with any questions or concerns
          </p>
          <div className="flex justify-center gap-4">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold transition-all">
              Contact Support
            </button>
            <button className="border border-gray-600 hover:border-gray-500 px-8 py-4 rounded-lg font-semibold transition-all">
              Schedule a Call
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Support;